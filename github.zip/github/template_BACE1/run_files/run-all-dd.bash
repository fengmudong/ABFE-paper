cd rest
cp ./run_files/run-rest.bash ./
source run-rest.bash
cd ../
cd dd/
cp ./run_files/run-dd-site.bash ./
cp ./run_files/run-dd-bulk.bash ./
source run-dd-site.bash
source run-dd-bulk.bash
cd ../
