cd rest
cp ./run_files/run-rest.bash ./
source run-rest.bash
cd ../
cd sdr/
cp ./run_files/run-dd-site.bash ./
source run-dd-site.bash
cd ../../
